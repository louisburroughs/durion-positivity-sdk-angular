export * from '../../models/bulkIngestResult';
