export * from '../../models/locationTypeDTO';
