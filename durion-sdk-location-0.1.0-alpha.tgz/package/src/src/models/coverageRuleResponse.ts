export * from '../../models/coverageRuleResponse';
