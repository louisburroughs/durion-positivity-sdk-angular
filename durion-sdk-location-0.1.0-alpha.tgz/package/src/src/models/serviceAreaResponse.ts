export * from '../../models/serviceAreaResponse';
