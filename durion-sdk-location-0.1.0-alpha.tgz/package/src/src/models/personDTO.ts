export * from '../../models/personDTO';
